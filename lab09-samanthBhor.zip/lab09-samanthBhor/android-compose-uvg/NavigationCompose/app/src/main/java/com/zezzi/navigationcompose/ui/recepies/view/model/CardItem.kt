package com.zezzi.navigationcompose.ui.recepies.view.model

class CardItem(var recipe: String, var image: String)