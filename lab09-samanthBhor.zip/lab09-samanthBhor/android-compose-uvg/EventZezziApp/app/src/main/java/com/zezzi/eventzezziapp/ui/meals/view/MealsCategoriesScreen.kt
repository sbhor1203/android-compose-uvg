package com.zezzi.eventzezziapp.ui.meals.view

import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import com.zezzi.eventzezziapp.navigation.AppBar
import com.zezzi.eventzezziapp.data.networking.response.MealResponse
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.view.updateLayoutParams
import com.google.android.material.textview.MaterialTextView

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MealsCategoriesScreen(
    navController: NavController,
    viewModel: MealsCategoriesViewModel = viewModel()
) {
    val rememberedMeals: MutableState<List<MealResponse>> =
        remember { mutableStateOf(emptyList<MealResponse>()) }

    viewModel.getMeals { response ->
        val mealsFromTheApi = response?.categories
        rememberedMeals.value = mealsFromTheApi.orEmpty()
        LaunchedEffect(key1 = Unit) {
            try {
                val response = viewModel.getMeals()
                rememberedMeals.value = response?.categories.orEmpty()
            } catch (e: Exception) {
                null
            }
    }

    Scaffold(
        topBar = {
            AppBar(title = "Categories", navController = navController)
            AppBar(title = "New Recipies", navController = navController)
        }
    ) {
        LazyColumn(contentPadding = it) {
            items(rememberedMeals.value) { meal ->
                Text(text = meal.name)

                Column(

                            class MainActivity : AppCompatActivity() {

                                override fun onCreate(savedInstanceState: Bundle?) {
                                    super.onCreate(savedInstanceState)
                                    setContentView(R.layout.activity_main)

                                    val constraintLayout = findViewById<ConstraintLayout>(R.id.constraintLayout)

                                    val card1 = CardView(this)
                                    card1.id = View.generateViewId()
                                    card1.cardBackgroundColor = getColor(R.color.white)
                                    card1.radius = resources.getDimension(R.dimen.card_corner_radius)
                                    card1.cardElevation = resources.getDimension(R.dimen.card_elevation)

                                    val textView1 = MaterialTextView(this)
                                    textView1.id = View.generateViewId()
                                    textView1.text = "Hamburger"
                                    textView1.setTextColor(getColor(R.color.black))
                                    textView1.textSize = resources.getDimension(R.dimen.text_size)
                                    textView1.gravity = Gravity.CENTER

                                    constraintLayout.addView(card1)
                                    card1.addView(textView1)

                                    val card1 = CardView(this)
                                    card1.id = View.generateViewId()
                                    card1.cardBackgroundColor = getColor(R.color.white)
                                    card1.radius = resources.getDimension(R.dimen.card_corner_radius)
                                    card1.cardElevation = resources.getDimension(R.dimen.card_elevation)

                                    val textView1 = MaterialTextView(this)
                                    textView1.id = View.generateViewId()
                                    textView1.text = "Pizza"
                                    textView1.setTextColor(getColor(R.color.black))
                                    textView1.textSize = resources.getDimension(R.dimen.text_size)
                                    textView1.gravity = Gravity.CENTER

                                    constraintLayout.addView(card1)
                                    card1.addView(textView1)



                                }
                            }

                )
            }
        }
    }
}