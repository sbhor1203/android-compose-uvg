package com.zezzi.labcompose2

class CardItem(var recipe: String, var image: String)
