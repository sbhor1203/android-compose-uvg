package com.zezzi.labcompose2

import androidx.compose.runtime.Composable

@Composable
fun DetailScreen() {}
